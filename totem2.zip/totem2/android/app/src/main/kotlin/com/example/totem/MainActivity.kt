package com.example.totem

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
